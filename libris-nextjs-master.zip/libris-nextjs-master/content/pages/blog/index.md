---
title: Blog
subtitle: This is an optional subtitle for the blog page
image: images/5.jpg
has_more_link: true
more_link_text: Read more
seo:
  title: Blog
  description: This is the blog page
  extra:
    - name: 'og:type'
      value: website
      keyName: property
    - name: 'og:title'
      value: Blog
      keyName: property
    - name: 'og:description'
      value: This is the blog page
      keyName: property
    - name: 'og:image'
      value: images/5.jpg
      keyName: property
      relativeUrl: true
    - name: 'twitter:card'
      value: summary_large_image
    - name: 'twitter:title'
      value: Blog
    - name: 'twitter:description'
      value: This is the blog page
    - name: 'twitter:image'
      value: images/5.jpg
      relativeUrl: true
layout: blog
---
